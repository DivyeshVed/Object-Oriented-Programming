import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedListIterator<T> implements Iterator<T> {
    private Node<T> curr;
      
    public LinkedListIterator(LinkedList<T> list) {
        curr = list.getHead();
    }
    
    @Override
    public boolean hasNext() {
        return curr != null;
    }

    @Override
    public T next() {
        if(hasNext() == false) {
            throw new NoSuchElementException("no next element");
        }
        T data = curr.getData();
        curr = curr.getNext();
        return data;
    }
}
